// Simple client-side behavior for demo only (no backend)
document.addEventListener('DOMContentLoaded', function(){
  var uploadForm = document.getElementById('uploadForm');
  if(uploadForm){
    uploadForm.addEventListener('submit', function(e){
      e.preventDefault();
      alert('Asante! Form imepokelewa (demo). Utahitaji backend ku-save data.');
      uploadForm.reset();
    });
  }
  var contactForm = document.getElementById('contactForm');
  if(contactForm){
    contactForm.addEventListener('submit', function(e){
      e.preventDefault();
      alert('Asante! Ujumbe umepelekwa (demo). Tutakujibu kupitia barua pepe.');
      contactForm.reset();
    });
  }
});
